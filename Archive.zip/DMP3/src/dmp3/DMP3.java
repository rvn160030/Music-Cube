/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmp3;

import java.io.File;
import java.util.List;
import javafx.application.Application;
import javafx.collections.MapChangeListener;
import javafx.collections.MapChangeListener.Change;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

/**
 *
 * @author vincentnoble
 */
public class DMP3 extends Application {
    
    private ImageView albumCover;
    private MediaPlayer mp;
    private Media song;
    private List<File> playlist;
    
    private void setUpMedia(){
        song = new Media("file://" + playlist.get(0).getPath());
        song.getMetadata().addListener(new MapChangeListener<String, Object>() {
        @Override
        public void onChanged(Change<? extends String, ? extends Object> ch) {
          if (ch.wasAdded()) {
            extractMedia(ch.getKey().toLowerCase(), ch.getValueAdded());
          }
        }
      });
        
    }
    
    private void extractMedia(String key, Object value){
        switch(key){
            case "image":
                albumCover.setImage((Image) value);
        }
    }
    @Override
    public void start(Stage primaryStage) {
        StackPane root = new StackPane();
        Label dragHere = new Label("Drag files here");
        dragHere.setOnDragOver(new EventHandler<DragEvent>(){
            @Override
            public void handle(DragEvent de){
                if(de.getDragboard().hasFiles()){
                de.acceptTransferModes(TransferMode.ANY);
                }
            }
        });
        dragHere.setOnDragDropped(new EventHandler<DragEvent>(){
            public void handle(DragEvent de){
                playlist = de.getDragboard().getFiles();
                setUpMedia();
                StackPane pane2 = new StackPane();
                Scene scene2 = new Scene(pane2, 500, 500);
                pane2.getChildren().add(albumCover);
                primaryStage.setScene(scene2);
            }
        });
        root.getChildren().add(dragHere);
        Scene scene1 = new Scene(root, 500, 500);        
        primaryStage.setTitle("Drag MP3 Files");
        primaryStage.setScene(scene1);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
